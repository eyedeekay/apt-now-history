intelmetool
===========

Compiling:

You need libpci-dev

```
make
sudo ./intelmetool
```
