---------------------------------------------------------------------------
-- @author Gregor Best
-- @copyright 2008 Gregor Best
-- @release v3.5.9
---------------------------------------------------------------------------

--- Dummy function for floating layout
-- awful.layout.suit.floating
local floating = {}

function floating.arrange()
end

floating.name = "floating"

return floating
