# svirfneblin
Re-implementing gnome-panel(sorta) as an awesome config. Considered calling it "mutterfixer."
